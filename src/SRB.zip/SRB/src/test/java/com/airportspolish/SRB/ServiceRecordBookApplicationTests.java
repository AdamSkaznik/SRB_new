package com.airportspolish.SRB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRecordBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
