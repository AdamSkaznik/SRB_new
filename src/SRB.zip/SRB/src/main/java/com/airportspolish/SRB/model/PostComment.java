/*
 * Copyright (c) 2023. Adam Skaźnik for SOL PPL Chopin Airport
 * All rights reserved.
 */

package com.airportspolish.SRB.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//@AllArgsConstructor
//@NoArgsConstructor
//@Getter
//@Setter
//@Entity
//@Table(name = "tab_post_comments")
//public class PostComment extends Post{
public class PostComment {
//    @ManyToOne
//    @JoinColumn(name = "idPost")
//    private ForumPost post;
//
//    public ForumPost getPost() {
//        return post;
//    }
//
//    @ManyToOne
//    @JoinColumn(name = "user_id")
//    private User user;
}
