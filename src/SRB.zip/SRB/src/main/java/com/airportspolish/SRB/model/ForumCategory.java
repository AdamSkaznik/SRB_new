/*
 * Copyright (c) 2023. Adam Skaźnik for SOL PPL Chopin Airport
 * All rights reserved.
 */

package com.airportspolish.SRB.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

//@AllArgsConstructor
//@NoArgsConstructor
//@Getter
//@Setter
//@Entity
//@Table(name = "tab_forum_category")
public class ForumCategory {
//    @Id
//    @GeneratedValue(strategy= GenerationType.IDENTITY)
//    private Long id;
//
//    @NotNull
//    @Size(min = 3, max = 70, message="Temat jest za krótki")
//    private String title;
//
//    @NotNull
//    @Size(min = 5, max = 100, message="Opis jest za krótki")
//    private String description;

//    @OneToMany(mappedBy = "category")
//    private List<ForumPost> posts;
}
