/*
 * Copyright (c) 2023. Adam Skaźnik for SOL PPL Chopin Airport
 * All rights reserved.
 */

package com.airportspolish.SRB.model;

import org.springframework.data.jpa.repository.Temporal;

import javax.persistence.Transient;
import java.time.LocalTime;
import java.util.Date;
import java.util.List;
import java.util.Set;

public class EventSearch{

//
//    @Transient
//    private String date1Tmp;
//    @Transient
//    private String date2Tmp;
//
//
//
//    public EventSearch(String date1Tmp, String date2Tmp) {
//        this.date1Tmp = date1Tmp;
//        this.date2Tmp = date2Tmp;
//    }
}
