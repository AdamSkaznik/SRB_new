/*
 * Copyright (c) 2023. Adam Skaźnik for SOL PPL Chopin Airport
 * All rights reserved.
 */

package com.airportspolish.SRB.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.sql.Timestamp;

//@MappedSuperclass
//@AllArgsConstructor
//@NoArgsConstructor
//@Getter
//@Setter
//public abstract class Post {
public class Post {
//    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
//    private Long id;
//
//    @NotNull
//    @Size(min = 5, max = 300, message = "Wiadomość musi zawierać minimum {min}, maximum {max} znaków")
//    private String content;
//
//    private Timestamp date;
}
