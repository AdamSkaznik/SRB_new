/*
 * Copyright (c) 2023. Adam Skaźnik for SOL PPL Chopin Airport
 * All rights reserved.
 */

package com.airportspolish.SRB.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

//@AllArgsConstructor
//@NoArgsConstructor
//@Getter
//@Setter
//@Entity
//@Table(name = "tab_forum_post")
//public class ForumPost extends Post{
public class ForumPost {
//    @NotNull
//    @Size(min = 5, max = 70, message = "Title must conatin {min} to {max} letters")
//    private String title;

//    @ManyToOne
//    @JoinColumn(name = "user_id")
//    private User user;
//
//    @ManyToOne
//    @JoinColumn(name = "idCategory")
//    private ForumCategory category;
//
//    @OneToMany(mappedBy = "post")
//    private List<PostComment> comments;
}
